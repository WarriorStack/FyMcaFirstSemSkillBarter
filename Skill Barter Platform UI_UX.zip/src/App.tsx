import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { LandingPage } from "./components/LandingPage";
import { AuthPage } from "./components/AuthPage";
import { Dashboard } from "./components/Dashboard";
import { ProfilePage } from "./components/ProfilePage";
import { SkillExplorerPage } from "./components/SkillExplorerPage";
import { CollaborationPage } from "./components/CollaborationPage";
import { ReviewPage } from "./components/ReviewPage";
import { AdminPanel } from "./components/AdminPanel";
import { SupportPage } from "./components/SupportPage";
import { LoadingPage } from "./components/LoadingPage";
import { NotFoundPage } from "./components/NotFoundPage";
import { Toaster } from "./components/ui/sonner";

type Page = 
  | 'loading'
  | 'landing'
  | 'auth'
  | 'dashboard'
  | 'profile'
  | 'skills'
  | 'collaboration'
  | 'reviews'
  | 'admin'
  | 'support'
  | '404';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('loading');

  useEffect(() => {
    // Simulate initial loading
    const timer = setTimeout(() => {
      setCurrentPage('landing');
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const navigateTo = (page: Page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'loading':
        return <LoadingPage />;
      case 'landing':
        return <LandingPage onNavigate={navigateTo} />;
      case 'auth':
        return <AuthPage onNavigate={navigateTo} />;
      case 'dashboard':
        return <Dashboard onNavigate={navigateTo} />;
      case 'profile':
        return <ProfilePage onNavigate={navigateTo} />;
      case 'skills':
        return <SkillExplorerPage onNavigate={navigateTo} />;
      case 'collaboration':
        return <CollaborationPage onNavigate={navigateTo} />;
      case 'reviews':
        return <ReviewPage onNavigate={navigateTo} />;
      case 'admin':
        return <AdminPanel onNavigate={navigateTo} />;
      case 'support':
        return <SupportPage onNavigate={navigateTo} />;
      case '404':
        return <NotFoundPage onNavigate={navigateTo} />;
      default:
        return <NotFoundPage onNavigate={navigateTo} />;
    }
  };

  return (
    <>
      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          {renderPage()}
        </motion.div>
      </AnimatePresence>
      <Toaster />
    </>
  );
}

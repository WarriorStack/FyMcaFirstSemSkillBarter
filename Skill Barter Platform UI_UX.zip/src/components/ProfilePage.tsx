import { motion } from "motion/react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Progress } from "./ui/progress";
import {
  Trophy,
  Star,
  Code,
  Palette,
  BookOpen,
  Award,
  Calendar,
  MapPin,
  Mail,
  ExternalLink,
  Edit,
  Sparkles,
} from "lucide-react";

const skills = [
  { name: "React Development", level: 85, icon: Code, color: "bg-blue-500" },
  { name: "UI/UX Design", level: 75, icon: Palette, color: "bg-purple-500" },
  { name: "Content Writing", level: 70, icon: BookOpen, color: "bg-yellow-500" },
];

const projects = [
  {
    id: 1,
    title: "E-commerce Platform",
    description: "Built a full-stack e-commerce site with React and Node.js",
    date: "Oct 2024",
    collaborators: 2,
    skills: ["React", "Node.js", "MongoDB"],
  },
  {
    id: 2,
    title: "Brand Identity Package",
    description: "Designed complete brand identity for a startup",
    date: "Sep 2024",
    collaborators: 1,
    skills: ["Figma", "Illustrator", "Branding"],
  },
  {
    id: 3,
    title: "Blog Content Strategy",
    description: "Created SEO-optimized content calendar and articles",
    date: "Aug 2024",
    collaborators: 1,
    skills: ["SEO", "Copywriting", "Strategy"],
  },
];

const reviews = [
  {
    id: 1,
    reviewer: "Sarah Chen",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    rating: 5,
    text: "Excellent collaboration! John is very skilled in React and helped me build a complex feature.",
    date: "1 week ago",
    skill: "React Development",
  },
  {
    id: 2,
    reviewer: "Marcus Johnson",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    rating: 5,
    text: "Great communication and amazing design skills. Really enjoyed working together!",
    date: "2 weeks ago",
    skill: "UI/UX Design",
  },
];

const achievements = [
  { title: "Early Adopter", desc: "Joined in the first 100 users", icon: Trophy, color: "bg-yellow-500" },
  { title: "Helpful Mentor", desc: "Helped 10+ students", icon: Award, color: "bg-blue-500" },
  { title: "Skill Master", desc: "Mastered 5+ skills", icon: Star, color: "bg-purple-500" },
  { title: "Active Learner", desc: "50+ collaborations completed", icon: Sparkles, color: "bg-green-500" },
];

const timeline = [
  { date: "Nov 2024", event: "Completed E-commerce project", type: "project" },
  { date: "Oct 2024", event: "Earned 500 skill points milestone", type: "milestone" },
  { date: "Sep 2024", event: "Achieved 4.8 average rating", type: "achievement" },
  { date: "Aug 2024", event: "Joined Skill Barter Platform", type: "joined" },
];

export function ProfilePage({ onNavigate }: { onNavigate: (page: string) => void }) {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header with Back Button */}
        <Button
          variant="ghost"
          onClick={() => onNavigate('dashboard')}
          className="mb-6"
        >
          ← Back to Dashboard
        </Button>

        {/* Profile Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="p-8 mb-8 relative overflow-hidden">
            <div 
              className="absolute inset-0 opacity-5"
              style={{
                background: "linear-gradient(135deg, #6C63FF 0%, #4A90E2 100%)",
              }}
            />
            
            <div className="relative z-10 flex flex-col md:flex-row gap-8 items-start">
              <div className="relative">
                <motion.div
                  animate={{
                    boxShadow: [
                      "0 0 0 0 rgba(74, 144, 226, 0.4)",
                      "0 0 0 20px rgba(74, 144, 226, 0)",
                    ],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                  }}
                  className="rounded-full"
                >
                  <Avatar className="w-32 h-32 border-4 border-white shadow-xl">
                    <AvatarImage src="https://images.unsplash.com/photo-1556157382-97eda2d62296?w=200&h=200&fit=crop" />
                    <AvatarFallback>JD</AvatarFallback>
                  </Avatar>
                </motion.div>
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.3 }}
                  className="absolute -bottom-2 -right-2 bg-primary text-white w-10 h-10 rounded-full flex items-center justify-center shadow-lg"
                >
                  <Trophy className="w-5 h-5" />
                </motion.div>
              </div>

              <div className="flex-1">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h1 className="text-4xl mb-2">John Doe</h1>
                    <div className="flex items-center gap-4 text-muted-foreground mb-3">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        San Francisco, CA
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        Joined Aug 2024
                      </div>
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4" />
                        john@college.edu
                      </div>
                    </div>
                    <div className="flex items-center gap-2 mb-4">
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-5 h-5 ${
                              i < 4 ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-muted-foreground">4.8 (24 reviews)</span>
                    </div>
                  </div>
                  <Button className="gap-2">
                    <Edit className="w-4 h-4" />
                    Edit Profile
                  </Button>
                </div>

                <p className="text-muted-foreground mb-6 max-w-2xl">
                  Computer Science student passionate about web development and design. 
                  Love to collaborate on innovative projects and help others learn coding. 
                  Always looking to expand my skill set and contribute to meaningful work.
                </p>

                <div className="flex flex-wrap gap-6">
                  <div>
                    <div className="text-3xl">1,247</div>
                    <div className="text-sm text-muted-foreground">Skill Points</div>
                  </div>
                  <div>
                    <div className="text-3xl">12</div>
                    <div className="text-sm text-muted-foreground">Skills Mastered</div>
                  </div>
                  <div>
                    <div className="text-3xl">24</div>
                    <div className="text-sm text-muted-foreground">Collaborations</div>
                  </div>
                  <div>
                    <div className="text-3xl">18</div>
                    <div className="text-sm text-muted-foreground">Students Helped</div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Tabs Section */}
        <Tabs defaultValue="skills" className="space-y-8">
          <TabsList className="grid w-full grid-cols-4 max-w-2xl">
            <TabsTrigger value="skills">Skills</TabsTrigger>
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
          </TabsList>

          {/* Skills Tab */}
          <TabsContent value="skills">
            <div className="grid md:grid-cols-2 gap-6">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <Card className="p-6">
                  <h3 className="text-xl mb-6">My Skills</h3>
                  <div className="space-y-6">
                    {skills.map((skill, idx) => (
                      <motion.div
                        key={idx}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.1 }}
                      >
                        <div className="flex items-center gap-3 mb-2">
                          <div className={`${skill.color} w-10 h-10 rounded-lg flex items-center justify-center`}>
                            <skill.icon className="w-5 h-5 text-white" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-1">
                              <span>{skill.name}</span>
                              <span className="text-sm text-muted-foreground">{skill.level}%</span>
                            </div>
                            <Progress value={skill.level} className="h-2" />
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                  <Button className="w-full mt-6" variant="outline">
                    Add New Skill
                  </Button>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <Card className="p-6">
                  <h3 className="text-xl mb-6">Collaboration Timeline</h3>
                  <div className="space-y-4">
                    {timeline.map((item, idx) => (
                      <motion.div
                        key={idx}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        className="flex gap-4"
                      >
                        <div className="relative">
                          <div className="w-3 h-3 rounded-full bg-primary" />
                          {idx < timeline.length - 1 && (
                            <div className="absolute top-3 left-1/2 -translate-x-1/2 w-0.5 h-16 bg-border" />
                          )}
                        </div>
                        <div className="flex-1 pb-8">
                          <div className="text-xs text-muted-foreground mb-1">{item.date}</div>
                          <div>{item.event}</div>
                          <Badge variant="outline" className="mt-2 text-xs">
                            {item.type}
                          </Badge>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </Card>
              </motion.div>
            </div>
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project, idx) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  whileHover={{ y: -5 }}
                >
                  <Card className="p-6 h-full hover:shadow-xl transition-shadow">
                    <div className="flex items-start justify-between mb-4">
                      <h4 className="text-lg">{project.title}</h4>
                      <ExternalLink className="w-5 h-5 text-muted-foreground cursor-pointer hover:text-primary" />
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">{project.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.skills.map((skill, idx) => (
                        <Badge key={idx} variant="secondary">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <span>{project.date}</span>
                      <span>{project.collaborators} collaborators</span>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Reviews Tab */}
          <TabsContent value="reviews">
            <div className="max-w-4xl space-y-6">
              {reviews.map((review, idx) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                >
                  <Card className="p-6">
                    <div className="flex items-start gap-4">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={review.avatar} />
                        <AvatarFallback>{review.reviewer[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <div>{review.reviewer}</div>
                            <div className="text-sm text-muted-foreground">{review.date}</div>
                          </div>
                          <div className="flex items-center gap-1">
                            {[...Array(review.rating)].map((_, i) => (
                              <Star key={i} className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                            ))}
                          </div>
                        </div>
                        <Badge variant="outline" className="mb-3">
                          {review.skill}
                        </Badge>
                        <p className="text-muted-foreground italic">"{review.text}"</p>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {achievements.map((achievement, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.1 }}
                  whileHover={{ scale: 1.05, rotate: 5 }}
                >
                  <Card className="p-6 text-center hover:shadow-xl transition-shadow">
                    <div className={`${achievement.color} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg`}>
                      <achievement.icon className="w-8 h-8 text-white" />
                    </div>
                    <h4 className="mb-2">{achievement.title}</h4>
                    <p className="text-sm text-muted-foreground">{achievement.desc}</p>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

import { motion } from "motion/react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import {
  Users,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Search,
  Download,
  Filter,
  Sparkles,
  Activity,
} from "lucide-react";

const userGrowthData = [
  { month: "Jun", users: 1200 },
  { month: "Jul", users: 1800 },
  { month: "Aug", users: 2400 },
  { month: "Sep", users: 3200 },
  { month: "Oct", users: 4100 },
  { month: "Nov", users: 5000 },
];

const skillDistribution = [
  { name: "Development", value: 35, color: "#4A90E2" },
  { name: "Design", value: 25, color: "#6C63FF" },
  { name: "Writing", value: 20, color: "#FFC857" },
  { name: "Marketing", value: 12, color: "#10B981" },
  { name: "Other", value: 8, color: "#F59E0B" },
];

const engagementData = [
  { day: "Mon", active: 420, collaborations: 85 },
  { day: "Tue", active: 480, collaborations: 92 },
  { day: "Wed", active: 510, collaborations: 98 },
  { day: "Thu", active: 550, collaborations: 110 },
  { day: "Fri", active: 490, collaborations: 95 },
  { day: "Sat", active: 320, collaborations: 65 },
  { day: "Sun", active: 280, collaborations: 55 },
];

const recentTransactions = [
  { id: 1, user: "Sarah Chen", action: "Completed collaboration", points: 450, status: "success" },
  { id: 2, user: "Marcus Johnson", action: "Started new project", points: 0, status: "active" },
  { id: 3, user: "Emily Rodriguez", action: "Earned milestone", points: 200, status: "success" },
  { id: 4, user: "Alex Kim", action: "Reported issue", points: 0, status: "pending" },
  { id: 5, user: "Lisa Wang", action: "Skill verified", points: 100, status: "success" },
];

export function AdminPanel({ onNavigate }: { onNavigate: (page: string) => void }) {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" onClick={() => onNavigate('dashboard')} className="mb-6">
            ← Back to Dashboard
          </Button>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl mb-2">Admin Dashboard</h1>
            <p className="text-xl text-muted-foreground">
              Monitor platform analytics and manage user activities
            </p>
          </motion.div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[
            {
              label: "Total Users",
              value: "5,247",
              change: "+12.5%",
              icon: Users,
              color: "bg-blue-500",
            },
            {
              label: "Active Collaborations",
              value: "892",
              change: "+8.3%",
              icon: Activity,
              color: "bg-green-500",
            },
            {
              label: "Total Skill Points",
              value: "2.4M",
              change: "+18.2%",
              icon: Sparkles,
              color: "bg-yellow-500",
            },
            {
              label: "Platform Health",
              value: "98.5%",
              change: "+0.5%",
              icon: TrendingUp,
              color: "bg-purple-500",
            },
          ].map((metric, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
            >
              <Card className="p-6 hover:shadow-xl transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className={`${metric.color} w-12 h-12 rounded-xl flex items-center justify-center`}>
                    <metric.icon className="w-6 h-6 text-white" />
                  </div>
                  <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                    {metric.change}
                  </Badge>
                </div>
                <div className="text-3xl mb-1">{metric.value}</div>
                <div className="text-sm text-muted-foreground">{metric.label}</div>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* User Growth Chart */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl">User Growth</h3>
                <Button variant="outline" size="sm" className="gap-2">
                  <Download className="w-4 h-4" />
                  Export
                </Button>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={userGrowthData}>
                  <defs>
                    <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4A90E2" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#4A90E2" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="month" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "white",
                      border: "1px solid #E5E7EB",
                      borderRadius: "0.5rem",
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="users"
                    stroke="#4A90E2"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#colorUsers)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </Card>
          </motion.div>

          {/* Skill Distribution */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="p-6">
              <h3 className="text-xl mb-6">Skill Distribution</h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={skillDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {skillDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          </motion.div>
        </div>

        {/* Weekly Engagement */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-8"
        >
          <Card className="p-6">
            <h3 className="text-xl mb-6">Weekly Engagement</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={engagementData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="day" stroke="#6B7280" />
                <YAxis stroke="#6B7280" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "white",
                    border: "1px solid #E5E7EB",
                    borderRadius: "0.5rem",
                  }}
                />
                <Legend />
                <Bar dataKey="active" fill="#4A90E2" radius={[8, 8, 0, 0]} />
                <Bar dataKey="collaborations" fill="#6C63FF" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </motion.div>

        {/* Recent Activity Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl">Recent Transactions</h3>
              <div className="flex gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input placeholder="Search..." className="pl-9 w-64" />
                </div>
                <Button variant="outline" size="icon">
                  <Filter className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Points</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentTransactions.map((transaction, idx) => (
                  <motion.tr
                    key={transaction.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.6 + idx * 0.05 }}
                    className="border-b"
                  >
                    <TableCell>{transaction.user}</TableCell>
                    <TableCell>{transaction.action}</TableCell>
                    <TableCell>
                      {transaction.points > 0 ? (
                        <span className="text-green-600">+{transaction.points}</span>
                      ) : (
                        "-"
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          transaction.status === "success"
                            ? "default"
                            : transaction.status === "active"
                            ? "secondary"
                            : "outline"
                        }
                      >
                        {transaction.status === "success" && (
                          <CheckCircle className="w-3 h-3 mr-1" />
                        )}
                        {transaction.status === "pending" && (
                          <AlertCircle className="w-3 h-3 mr-1" />
                        )}
                        {transaction.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm">
                        View
                      </Button>
                    </TableCell>
                  </motion.tr>
                ))}
              </TableBody>
            </Table>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}

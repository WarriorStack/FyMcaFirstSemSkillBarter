import { motion } from "motion/react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { 
  Sparkles, 
  Users, 
  Target, 
  TrendingUp, 
  ArrowRight,
  BookOpen,
  Code,
  Palette,
  Music,
  Camera,
  Lightbulb
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const floatingIcons = [
  { Icon: BookOpen, delay: 0, x: "10%", y: "20%" },
  { Icon: Code, delay: 0.2, x: "80%", y: "15%" },
  { Icon: Palette, delay: 0.4, x: "15%", y: "70%" },
  { Icon: Music, delay: 0.6, x: "85%", y: "65%" },
  { Icon: Camera, delay: 0.8, x: "50%", y: "80%" },
  { Icon: Lightbulb, delay: 1, x: "70%", y: "40%" },
];

const popularSkills = [
  { name: "Web Development", count: "245 students", color: "bg-blue-500" },
  { name: "Graphic Design", count: "189 students", color: "bg-purple-500" },
  { name: "Content Writing", count: "156 students", color: "bg-yellow-500" },
  { name: "Photography", count: "134 students", color: "bg-green-500" },
  { name: "Music Production", count: "98 students", color: "bg-pink-500" },
  { name: "Data Analysis", count: "87 students", color: "bg-indigo-500" },
];

const testimonials = [
  {
    name: "Sarah Chen",
    role: "Computer Science Student",
    text: "I taught Python and learned UI design. Best exchange ever!",
    avatar: "https://images.unsplash.com/photo-1556157382-97eda2d62296?w=100&h=100&fit=crop",
    rating: 5
  },
  {
    name: "Marcus Johnson",
    role: "Business Major",
    text: "Found amazing collaborators who helped me build my startup idea.",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    rating: 5
  },
  {
    name: "Emily Rodriguez",
    role: "Art Student",
    text: "Traded graphic design for marketing skills. Such a vibrant community!",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    rating: 5
  },
];

export function LandingPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  return (
    <div className="min-h-screen overflow-hidden">
      {/* Floating Background Icons */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {floatingIcons.map(({ Icon, delay, x, y }, idx) => (
          <motion.div
            key={idx}
            className="absolute opacity-10"
            style={{ left: x, top: y }}
            animate={{
              y: [0, -20, 0],
              rotate: [0, 10, -10, 0],
            }}
            transition={{
              duration: 3,
              delay,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <Icon className="w-16 h-16 text-primary" />
          </motion.div>
        ))}
      </div>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 py-20">
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            background: "linear-gradient(135deg, #6C63FF 0%, #4A90E2 100%)",
          }}
        />
        
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center relative z-10">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring" }}
              className="inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg"
            >
              <Sparkles className="w-5 h-5 text-accent" />
              <span className="text-sm">Welcome to the Future of Learning</span>
            </motion.div>

            <h1 className="text-5xl lg:text-7xl">
              Exchange Skills.<br />
              <span className="text-primary">Build Futures.</span>
            </h1>

            <p className="text-xl text-muted-foreground max-w-lg">
              Join thousands of college students trading knowledge, building projects, 
              and growing together on the ultimate skill barter platform.
            </p>

            <div className="flex flex-wrap gap-4">
              <Button 
                size="lg" 
                className="bg-primary hover:bg-primary/90 shadow-xl shadow-primary/30 group"
                onClick={() => onNavigate('auth')}
              >
                Get Started
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="backdrop-blur-sm"
                onClick={() => onNavigate('skills')}
              >
                Explore Skills
              </Button>
            </div>

            <div className="flex items-center gap-8 pt-8">
              <div>
                <div className="flex items-baseline gap-1">
                  <motion.span 
                    className="text-4xl"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                  >
                    5,000+
                  </motion.span>
                </div>
                <p className="text-sm text-muted-foreground">Active Students</p>
              </div>
              <div>
                <div className="flex items-baseline gap-1">
                  <motion.span 
                    className="text-4xl"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.7 }}
                  >
                    12,000+
                  </motion.span>
                </div>
                <p className="text-sm text-muted-foreground">Skills Exchanged</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="relative"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent rounded-3xl blur-3xl opacity-30" />
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1758270705518-b61b40527e76?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=800"
              alt="Students collaborating"
              className="relative rounded-3xl shadow-2xl w-full"
            />
          </motion.div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-4 relative">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl mb-4">How It Works</h2>
            <p className="text-xl text-muted-foreground">
              Three simple steps to start your skill exchange journey
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: "01",
                title: "Create Profile",
                desc: "Sign up and showcase your skills, expertise, and what you want to learn",
                Icon: Users,
                color: "bg-primary"
              },
              {
                step: "02",
                title: "Find Matches",
                desc: "Our AI connects you with students who have complementary skills",
                Icon: Target,
                color: "bg-accent"
              },
              {
                step: "03",
                title: "Start Learning",
                desc: "Collaborate on projects, exchange knowledge, and earn skill points",
                Icon: TrendingUp,
                color: "bg-secondary"
              },
            ].map((item, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.2 }}
              >
                <Card className="p-8 h-full backdrop-blur-sm bg-white/50 hover:shadow-xl transition-shadow border-2 border-transparent hover:border-primary/20">
                  <div className={`${item.color} w-16 h-16 rounded-2xl flex items-center justify-center mb-6 shadow-lg`}>
                    <item.Icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-sm text-muted-foreground mb-2">STEP {item.step}</div>
                  <h3 className="text-2xl mb-3">{item.title}</h3>
                  <p className="text-muted-foreground">{item.desc}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Skills Carousel */}
      <section className="py-20 px-4 bg-gradient-to-b from-transparent to-primary/5">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl mb-4">Popular Skills & Projects</h2>
            <p className="text-xl text-muted-foreground">
              Trending skills our community is exchanging right now
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {popularSkills.map((skill, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                whileHover={{ scale: 1.05, y: -5 }}
              >
                <Card className="p-6 text-center backdrop-blur-sm bg-white/70 hover:shadow-xl transition-all cursor-pointer">
                  <div className={`${skill.color} w-12 h-12 rounded-full mx-auto mb-4 shadow-lg`} />
                  <h4 className="mb-2">{skill.name}</h4>
                  <p className="text-sm text-muted-foreground">{skill.count}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl mb-4">What Students Say</h2>
            <p className="text-xl text-muted-foreground">
              Real experiences from our amazing community
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.15 }}
                whileHover={{ y: -10 }}
              >
                <Card className="p-8 h-full backdrop-blur-sm bg-white/70 hover:shadow-2xl transition-all">
                  <div className="flex gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Sparkles key={i} className="w-5 h-5 text-secondary fill-secondary" />
                    ))}
                  </div>
                  <p className="mb-6 text-muted-foreground italic">"{testimonial.text}"</p>
                  <div className="flex items-center gap-3">
                    <img
                      src={testimonial.avatar}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div>
                      <div>{testimonial.name}</div>
                      <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto"
        >
          <Card className="p-12 text-center relative overflow-hidden">
            <div 
              className="absolute inset-0 opacity-10"
              style={{
                background: "linear-gradient(135deg, #6C63FF 0%, #4A90E2 100%)",
              }}
            />
            <div className="relative z-10">
              <h2 className="text-4xl lg:text-5xl mb-6">Ready to Start Your Journey?</h2>
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Join our community today and unlock unlimited potential through skill exchange
              </p>
              <Button 
                size="lg"
                className="bg-accent hover:bg-accent/90 shadow-xl shadow-accent/30"
                onClick={() => onNavigate('auth')}
              >
                Join Now - It's Free!
              </Button>
            </div>
          </Card>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12 px-4 bg-white/50 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto grid md:grid-cols-4 gap-8">
          <div>
            <h3 className="mb-4 flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-primary" />
              Skill Barter
            </h3>
            <p className="text-sm text-muted-foreground">
              Empowering students to learn, grow, and collaborate through skill exchange.
            </p>
          </div>
          <div>
            <h4 className="mb-4">Platform</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <div className="hover:text-foreground cursor-pointer transition-colors">About Us</div>
              <div className="hover:text-foreground cursor-pointer transition-colors">How It Works</div>
              <div className="hover:text-foreground cursor-pointer transition-colors">Pricing</div>
            </div>
          </div>
          <div>
            <h4 className="mb-4">Resources</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <div className="hover:text-foreground cursor-pointer transition-colors">Help Center</div>
              <div className="hover:text-foreground cursor-pointer transition-colors">Community</div>
              <div className="hover:text-foreground cursor-pointer transition-colors">Blog</div>
            </div>
          </div>
          <div>
            <h4 className="mb-4">Legal</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <div className="hover:text-foreground cursor-pointer transition-colors">Privacy Policy</div>
              <div className="hover:text-foreground cursor-pointer transition-colors">Terms of Service</div>
              <div className="hover:text-foreground cursor-pointer transition-colors">Cookie Policy</div>
            </div>
          </div>
        </div>
        <div className="max-w-6xl mx-auto mt-8 pt-8 border-t text-center text-sm text-muted-foreground">
          © 2025 Skill Barter Platform. All rights reserved.
        </div>
      </footer>
    </div>
  );
}

import { useState } from "react";
import { motion } from "motion/react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Textarea } from "./ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Star, ThumbsUp, MessageCircle, Sparkles } from "lucide-react";

const reviews = [
  {
    id: 1,
    reviewer: "Sarah Chen",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    rating: 5,
    skill: "React Development",
    project: "E-commerce Platform",
    text: "John is an exceptional developer with deep knowledge of React and modern web technologies. He was patient, communicative, and delivered high-quality code. Our collaboration was smooth and productive. Highly recommend!",
    date: "Nov 1, 2024",
    helpful: 12,
    replies: 2,
  },
  {
    id: 2,
    reviewer: "Marcus Johnson",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    rating: 5,
    skill: "UI/UX Design",
    project: "Brand Identity Package",
    text: "Fantastic designer with great attention to detail. John understood our brand vision perfectly and created stunning visuals. His communication was excellent throughout the project.",
    date: "Oct 15, 2024",
    helpful: 8,
    replies: 1,
  },
  {
    id: 3,
    reviewer: "Emily Rodriguez",
    avatar: "https://images.unsplash.com/photo-1556157382-97eda2d62296?w=100&h=100&fit=crop",
    rating: 5,
    skill: "Content Writing",
    project: "Blog Content Strategy",
    text: "Working with John was a great experience. He helped me develop a comprehensive content strategy that increased our traffic significantly. Very creative and strategic thinker!",
    date: "Oct 1, 2024",
    helpful: 15,
    replies: 3,
  },
  {
    id: 4,
    reviewer: "Alex Kim",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    rating: 4,
    skill: "Web Development",
    project: "Portfolio Website",
    text: "John built an amazing portfolio site for me. The design is clean and modern, and the animations are smooth. Only minor issue was the timeline, but the end result was worth it.",
    date: "Sep 20, 2024",
    helpful: 6,
    replies: 0,
  },
  {
    id: 5,
    reviewer: "Lisa Wang",
    avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop",
    rating: 5,
    skill: "Graphic Design",
    project: "Social Media Templates",
    text: "Incredible designer! John created a complete set of social media templates that perfectly matched our brand. Fast turnaround and excellent quality. Will definitely collaborate again!",
    date: "Sep 5, 2024",
    helpful: 10,
    replies: 1,
  },
];

export function ReviewPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [showAddReview, setShowAddReview] = useState(false);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);

  const averageRating = (reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length).toFixed(1);
  const ratingDistribution = [
    { stars: 5, count: reviews.filter(r => r.rating === 5).length },
    { stars: 4, count: reviews.filter(r => r.rating === 4).length },
    { stars: 3, count: reviews.filter(r => r.rating === 3).length },
    { stars: 2, count: reviews.filter(r => r.rating === 2).length },
    { stars: 1, count: reviews.filter(r => r.rating === 1).length },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" onClick={() => onNavigate('dashboard')} className="mb-6">
            ← Back to Dashboard
          </Button>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl mb-2">Reviews & Testimonials</h1>
            <p className="text-xl text-muted-foreground">
              See what collaborators are saying about my work
            </p>
          </motion.div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Sidebar - Rating Overview */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card className="p-6 text-center">
                <div className="mb-4">
                  <div className="text-6xl mb-2">{averageRating}</div>
                  <div className="flex items-center justify-center gap-1 mb-2">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-6 h-6 ${
                          i < Math.round(parseFloat(averageRating))
                            ? "text-yellow-500 fill-yellow-500"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Based on {reviews.length} reviews
                  </div>
                </div>

                <div className="space-y-2 mb-6">
                  {ratingDistribution.map((dist) => (
                    <div key={dist.stars} className="flex items-center gap-2 text-sm">
                      <span className="w-12">{dist.stars} star</span>
                      <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${(dist.count / reviews.length) * 100}%` }}
                          transition={{ delay: 0.2, duration: 0.8 }}
                          className="bg-yellow-500 h-full"
                        />
                      </div>
                      <span className="w-8 text-muted-foreground">{dist.count}</span>
                    </div>
                  ))}
                </div>

                <Button className="w-full gap-2" onClick={() => setShowAddReview(true)}>
                  <Sparkles className="w-4 h-4" />
                  Write a Review
                </Button>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="p-6">
                <h4 className="mb-4">Review Highlights</h4>
                <div className="space-y-3">
                  {[
                    { label: "Communication", value: 98 },
                    { label: "Quality", value: 96 },
                    { label: "Timeliness", value: 92 },
                    { label: "Expertise", value: 97 },
                  ].map((metric, idx) => (
                    <div key={idx}>
                      <div className="flex items-center justify-between text-sm mb-1">
                        <span className="text-muted-foreground">{metric.label}</span>
                        <span>{metric.value}%</span>
                      </div>
                      <div className="bg-muted rounded-full h-2 overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${metric.value}%` }}
                          transition={{ delay: 0.3 + idx * 0.1, duration: 0.8 }}
                          className="bg-primary h-full"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>
          </div>

          {/* Main Reviews Section */}
          <div className="lg:col-span-2">
            <div className="space-y-6">
              {reviews.map((review, idx) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                >
                  <Card className="p-6 hover:shadow-xl transition-shadow">
                    <div className="flex items-start gap-4 mb-4">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={review.avatar} />
                        <AvatarFallback>{review.reviewer[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <div>{review.reviewer}</div>
                            <div className="text-sm text-muted-foreground">{review.date}</div>
                          </div>
                          <div className="flex items-center gap-1">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-5 h-5 ${
                                  i < review.rating
                                    ? "text-yellow-500 fill-yellow-500"
                                    : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        <div className="flex gap-2 mb-3">
                          <Badge variant="outline">{review.skill}</Badge>
                          <Badge variant="secondary">{review.project}</Badge>
                        </div>
                      </div>
                    </div>

                    <p className="text-muted-foreground mb-4 leading-relaxed">
                      "{review.text}"
                    </p>

                    <div className="flex items-center gap-4 pt-4 border-t">
                      <Button variant="ghost" size="sm" className="gap-2">
                        <ThumbsUp className="w-4 h-4" />
                        Helpful ({review.helpful})
                      </Button>
                      <Button variant="ghost" size="sm" className="gap-2">
                        <MessageCircle className="w-4 h-4" />
                        Reply ({review.replies})
                      </Button>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="mt-8 text-center"
            >
              <Button variant="outline" size="lg">
                Load More Reviews
              </Button>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Add Review Dialog */}
      <Dialog open={showAddReview} onOpenChange={setShowAddReview}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Write a Review</DialogTitle>
            <DialogDescription>
              Share your experience working with this collaborator
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            <div>
              <label className="text-sm mb-2 block">Your Rating</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <motion.button
                    key={star}
                    type="button"
                    whileHover={{ scale: 1.2 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                  >
                    <Star
                      className={`w-10 h-10 transition-colors ${
                        star <= (hoverRating || rating)
                          ? "text-yellow-500 fill-yellow-500"
                          : "text-gray-300"
                      }`}
                    />
                  </motion.button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm mb-2 block">Skill/Project</label>
              <Input placeholder="e.g., Web Development - Portfolio Site" />
            </div>

            <div>
              <label className="text-sm mb-2 block">Your Review</label>
              <Textarea
                placeholder="Share details of your collaboration experience..."
                rows={6}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddReview(false)}>
              Cancel
            </Button>
            <Button onClick={() => setShowAddReview(false)}>
              Submit Review
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

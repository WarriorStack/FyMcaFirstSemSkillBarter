import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Search,
  Filter,
  Star,
  MapPin,
  Code,
  Palette,
  Music,
  Camera,
  BookOpen,
  TrendingUp,
  Users,
  Sparkles,
} from "lucide-react";

const skillCategories = [
  { name: "All Skills", icon: Sparkles, count: 245 },
  { name: "Development", icon: Code, count: 89 },
  { name: "Design", icon: Palette, count: 67 },
  { name: "Writing", icon: BookOpen, count: 45 },
  { name: "Music", icon: Music, count: 23 },
  { name: "Photography", icon: Camera, count: 21 },
];

const skillCards = [
  {
    id: 1,
    user: "Sarah Chen",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    skill: "React Development",
    category: "Development",
    level: "Expert",
    rating: 4.9,
    reviews: 24,
    location: "San Francisco, CA",
    availability: "Available",
    seeking: "UI/UX Design",
    points: 450,
    bio: "Senior developer with 3 years of React experience. Love building scalable applications.",
    tags: ["React", "TypeScript", "Next.js", "GraphQL"],
  },
  {
    id: 2,
    user: "Marcus Johnson",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    skill: "UI/UX Design",
    category: "Design",
    level: "Advanced",
    rating: 4.8,
    reviews: 18,
    location: "New York, NY",
    availability: "Available",
    seeking: "Web Development",
    points: 380,
    bio: "Product designer passionate about creating beautiful, user-friendly interfaces.",
    tags: ["Figma", "Adobe XD", "Prototyping", "User Research"],
  },
  {
    id: 3,
    user: "Emily Rodriguez",
    avatar: "https://images.unsplash.com/photo-1556157382-97eda2d62296?w=100&h=100&fit=crop",
    skill: "Content Writing",
    category: "Writing",
    level: "Expert",
    rating: 5.0,
    reviews: 31,
    location: "Austin, TX",
    availability: "Busy",
    seeking: "SEO & Marketing",
    points: 520,
    bio: "Professional writer specializing in tech and business content. Published in major blogs.",
    tags: ["Copywriting", "SEO", "Blog Posts", "Technical Writing"],
  },
  {
    id: 4,
    user: "Alex Kim",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    skill: "Data Analysis",
    category: "Development",
    level: "Advanced",
    rating: 4.7,
    reviews: 15,
    location: "Seattle, WA",
    availability: "Available",
    seeking: "Data Visualization",
    points: 310,
    bio: "Data scientist helping businesses make data-driven decisions.",
    tags: ["Python", "SQL", "Tableau", "Statistics"],
  },
  {
    id: 5,
    user: "Lisa Wang",
    avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop",
    skill: "Graphic Design",
    category: "Design",
    level: "Expert",
    rating: 4.9,
    reviews: 27,
    location: "Los Angeles, CA",
    availability: "Available",
    seeking: "Brand Strategy",
    points: 490,
    bio: "Creative designer with expertise in branding and visual identity.",
    tags: ["Illustrator", "Photoshop", "Branding", "Logo Design"],
  },
  {
    id: 6,
    user: "David Park",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    skill: "Photography",
    category: "Photography",
    level: "Advanced",
    rating: 4.6,
    reviews: 12,
    location: "Portland, OR",
    availability: "Available",
    seeking: "Photo Editing",
    points: 280,
    bio: "Portrait and landscape photographer. Love teaching composition and lighting.",
    tags: ["Portrait", "Landscape", "Lightroom", "Composition"],
  },
];

export function SkillExplorerPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All Skills");
  const [selectedUser, setSelectedUser] = useState<typeof skillCards[0] | null>(null);
  const [showDialog, setShowDialog] = useState(false);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  const filteredSkills = skillCards.filter((skill) => {
    const matchesSearch =
      skill.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      skill.skill.toLowerCase().includes(searchQuery.toLowerCase()) ||
      skill.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory =
      selectedCategory === "All Skills" || skill.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleConnect = (user: typeof skillCards[0]) => {
    setSelectedUser(user);
    setShowDialog(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" onClick={() => onNavigate('dashboard')} className="mb-6">
            ← Back to Dashboard
          </Button>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl mb-2">Explore Skills</h1>
            <p className="text-xl text-muted-foreground">
              Find the perfect collaborator and start your skill exchange journey
            </p>
          </motion.div>
        </div>

        {/* Search and Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <Card className="p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  placeholder="Search by skill, name, or tag..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select defaultValue="all">
                <SelectTrigger className="w-full lg:w-48">
                  <SelectValue placeholder="Difficulty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="beginner">Beginner</SelectItem>
                  <SelectItem value="advanced">Advanced</SelectItem>
                  <SelectItem value="expert">Expert</SelectItem>
                </SelectContent>
              </Select>
              <Select defaultValue="available">
                <SelectTrigger className="w-full lg:w-48">
                  <SelectValue placeholder="Availability" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">Available</SelectItem>
                  <SelectItem value="busy">Busy</SelectItem>
                  <SelectItem value="all">All</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" className="gap-2">
                <Filter className="w-4 h-4" />
                More Filters
              </Button>
            </div>
          </Card>
        </motion.div>

        {/* Category Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <div className="flex gap-3 overflow-x-auto pb-4">
            {skillCategories.map((category, idx) => (
              <motion.button
                key={category.name}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.05 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedCategory(category.name)}
                className={`flex items-center gap-2 px-6 py-3 rounded-full whitespace-nowrap transition-all ${
                  selectedCategory === category.name
                    ? "bg-primary text-white shadow-lg shadow-primary/30"
                    : "bg-white hover:bg-muted"
                }`}
              >
                <category.icon className="w-5 h-5" />
                <span>{category.name}</span>
                <Badge
                  variant={selectedCategory === category.name ? "secondary" : "outline"}
                  className="ml-1"
                >
                  {category.count}
                </Badge>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Results Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="text-sm text-muted-foreground">
            Found {filteredSkills.length} skilled collaborators
          </div>
          <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as any)}>
            <TabsList>
              <TabsTrigger value="grid">Grid</TabsTrigger>
              <TabsTrigger value="list">List</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Skill Cards */}
        <AnimatePresence mode="wait">
          <motion.div
            key={viewMode}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className={
              viewMode === "grid"
                ? "grid md:grid-cols-2 lg:grid-cols-3 gap-6"
                : "space-y-4"
            }
          >
            {filteredSkills.map((skill, idx) => (
              <motion.div
                key={skill.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                whileHover={{ y: -5 }}
              >
                <Card
                  className={`p-6 hover:shadow-xl transition-shadow cursor-pointer ${
                    viewMode === "list" ? "flex gap-6 items-start" : ""
                  }`}
                  onClick={() => handleConnect(skill)}
                >
                  <div className={viewMode === "list" ? "flex-shrink-0" : ""}>
                    <div className="relative mb-4">
                      <Avatar className="w-16 h-16">
                        <AvatarImage src={skill.avatar} />
                        <AvatarFallback>{skill.user[0]}</AvatarFallback>
                      </Avatar>
                      <div
                        className={`absolute -bottom-1 -right-1 w-6 h-6 rounded-full border-2 border-white ${
                          skill.availability === "Available"
                            ? "bg-green-500"
                            : "bg-yellow-500"
                        }`}
                      />
                    </div>
                  </div>

                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="text-lg mb-1">{skill.user}</h3>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                          <MapPin className="w-4 h-4" />
                          {skill.location}
                        </div>
                      </div>
                      <Badge variant={skill.level === "Expert" ? "default" : "secondary"}>
                        {skill.level}
                      </Badge>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Offering</div>
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-primary" />
                          <span>{skill.skill}</span>
                        </div>
                      </div>

                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Seeking</div>
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-accent" />
                          <span>{skill.seeking}</span>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {skill.tags.slice(0, 3).map((tag, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {skill.tags.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{skill.tags.length - 3}
                          </Badge>
                        )}
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                          <span className="text-sm">
                            {skill.rating} ({skill.reviews})
                          </span>
                        </div>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <TrendingUp className="w-4 h-4" />
                          {skill.points} points
                        </div>
                      </div>

                      <Button className="w-full" onClick={() => handleConnect(skill)}>
                        Connect
                      </Button>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Connect Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-4">
              <Avatar className="w-12 h-12">
                <AvatarImage src={selectedUser?.avatar} />
                <AvatarFallback>{selectedUser?.user[0]}</AvatarFallback>
              </Avatar>
              <div>
                <div className="text-xl">{selectedUser?.user}</div>
                <div className="text-sm text-muted-foreground">
                  {selectedUser?.skill} · {selectedUser?.location}
                </div>
              </div>
            </DialogTitle>
            <DialogDescription className="pt-4">
              <div className="space-y-6">
                <div>
                  <h4 className="mb-2">About</h4>
                  <p className="text-foreground">{selectedUser?.bio}</p>
                </div>

                <div>
                  <h4 className="mb-3">Skills & Expertise</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedUser?.tags.map((tag, idx) => (
                      <Badge key={idx} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-muted/30 rounded-lg">
                    <div className="text-sm text-muted-foreground mb-1">Rating</div>
                    <div className="flex items-center gap-2">
                      <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                      <span className="text-lg">
                        {selectedUser?.rating} ({selectedUser?.reviews} reviews)
                      </span>
                    </div>
                  </div>
                  <div className="p-4 bg-muted/30 rounded-lg">
                    <div className="text-sm text-muted-foreground mb-1">Skill Points</div>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-primary" />
                      <span className="text-lg">{selectedUser?.points}</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
                  <h4 className="mb-2 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-primary" />
                    AI Match Score: 92%
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    This collaborator is an excellent match based on your skills, interests, and collaboration history.
                  </p>
                </div>
              </div>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                setShowDialog(false);
                setTimeout(() => onNavigate('collaboration'), 300);
              }}
            >
              Send Collaboration Request
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { useState } from "react";
import { motion } from "motion/react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import {
  Home,
  Search,
  Users,
  FolderKanban,
  Trophy,
  Settings,
  Bell,
  Moon,
  Sun,
  Sparkles,
  TrendingUp,
  Code,
  Palette,
  BookOpen,
  LogOut,
  User,
} from "lucide-react";
import { LineChart, Line, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const activityData = [
  { name: 'Mon', points: 12 },
  { name: 'Tue', points: 19 },
  { name: 'Wed', points: 15 },
  { name: 'Thu', points: 25 },
  { name: 'Fri', points: 22 },
  { name: 'Sat', points: 30 },
  { name: 'Sun', points: 28 },
];

const skillData = [
  { skill: 'Web Dev', value: 85 },
  { skill: 'Design', value: 70 },
  { skill: 'Writing', value: 60 },
  { skill: 'Marketing', value: 75 },
  { skill: 'Data', value: 65 },
];

const activeCollabs = [
  {
    id: 1,
    title: "E-commerce Website",
    partner: "Sarah Chen",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    progress: 65,
    skill: "React Development",
  },
  {
    id: 2,
    title: "Brand Identity Design",
    partner: "Marcus Johnson",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    progress: 40,
    skill: "UI/UX Design",
  },
  {
    id: 3,
    title: "Content Strategy",
    partner: "Emily Rodriguez",
    avatar: "https://images.unsplash.com/photo-1556157382-97eda2d62296?w=100&h=100&fit=crop",
    progress: 80,
    skill: "Marketing",
  },
];

const navItems = [
  { icon: Home, label: "Dashboard", id: "dashboard" },
  { icon: Search, label: "Explore Skills", id: "skills" },
  { icon: Users, label: "Profile", id: "profile" },
  { icon: FolderKanban, label: "Projects", id: "collaboration" },
  { icon: Trophy, label: "Reviews", id: "reviews" },
  { icon: Settings, label: "Settings", id: "settings" },
];

export function Dashboard({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [activeNav, setActiveNav] = useState("dashboard");
  const [isDark, setIsDark] = useState(false);
  const [notifications] = useState(3);

  const handleNavClick = (id: string) => {
    setActiveNav(id);
    if (id !== 'dashboard' && id !== 'settings') {
      onNavigate(id);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <motion.aside
        initial={{ x: -300 }}
        animate={{ x: 0 }}
        className="fixed left-0 top-0 h-screen w-64 bg-white border-r p-6 flex flex-col z-50"
      >
        <div className="flex items-center gap-2 mb-10">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center"
          >
            <Sparkles className="w-5 h-5 text-white" />
          </motion.div>
          <span className="text-xl">Skill Barter</span>
        </div>

        <nav className="space-y-2 flex-1">
          {navItems.map((item, idx) => (
            <motion.button
              key={item.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.1 }}
              onClick={() => handleNavClick(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all group ${
                activeNav === item.id
                  ? "bg-primary text-white shadow-lg shadow-primary/30"
                  : "hover:bg-primary/5"
              }`}
            >
              <item.icon
                className={`w-5 h-5 transition-transform group-hover:scale-110 ${
                  activeNav === item.id ? "text-white" : "text-muted-foreground"
                }`}
              />
              <span>{item.label}</span>
            </motion.button>
          ))}
        </nav>

        <Button
          variant="outline"
          className="w-full justify-start gap-3"
          onClick={() => onNavigate('landing')}
        >
          <LogOut className="w-5 h-5" />
          Logout
        </Button>
      </motion.aside>

      {/* Main Content */}
      <div className="ml-64">
        {/* Top Bar */}
        <motion.header
          initial={{ y: -100 }}
          animate={{ y: 0 }}
          className="sticky top-0 bg-white/80 backdrop-blur-sm border-b px-8 py-4 flex items-center justify-between z-40"
        >
          <div className="flex-1 max-w-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search skills, people, projects..."
                className="pl-10 bg-background"
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              className="relative"
              onClick={() => {}}
            >
              <Bell className="w-5 h-5" />
              {notifications > 0 && (
                <motion.span
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-white text-xs rounded-full flex items-center justify-center"
                >
                  {notifications}
                </motion.span>
              )}
            </Button>

            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsDark(!isDark)}
            >
              {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-2 px-2">
                  <Avatar>
                    <AvatarImage src="https://images.unsplash.com/photo-1556157382-97eda2d62296?w=100&h=100&fit=crop" />
                    <AvatarFallback>JD</AvatarFallback>
                  </Avatar>
                  <div className="text-left hidden md:block">
                    <div className="text-sm">John Doe</div>
                    <div className="text-xs text-muted-foreground">Pro Member</div>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => onNavigate('profile')}>
                  <User className="w-4 h-4 mr-2" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => onNavigate('landing')}>
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </motion.header>

        {/* Dashboard Content */}
        <main className="p-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h1 className="text-4xl mb-2">Welcome back, John! 👋</h1>
            <p className="text-muted-foreground">
              You've earned 47 skill points this week. Keep up the great work!
            </p>
          </motion.div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[
              {
                label: "Skill Points",
                value: "1,247",
                change: "+47 this week",
                icon: Sparkles,
                color: "bg-primary",
                trend: "up",
              },
              {
                label: "Active Collaborations",
                value: "3",
                change: "2 ending soon",
                icon: Users,
                color: "bg-accent",
                trend: "neutral",
              },
              {
                label: "Skills Mastered",
                value: "12",
                change: "+2 this month",
                icon: Trophy,
                color: "bg-secondary",
                trend: "up",
              },
              {
                label: "Average Rating",
                value: "4.8",
                change: "94% positive",
                icon: TrendingUp,
                color: "bg-green-500",
                trend: "up",
              },
            ].map((stat, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                whileHover={{ y: -5, scale: 1.02 }}
              >
                <Card className="p-6 hover:shadow-xl transition-shadow">
                  <div className="flex items-start justify-between mb-4">
                    <div
                      className={`${stat.color} w-12 h-12 rounded-xl flex items-center justify-center shadow-lg`}
                    >
                      <stat.icon className="w-6 h-6 text-white" />
                    </div>
                    <Badge
                      variant={stat.trend === "up" ? "default" : "secondary"}
                      className="text-xs"
                    >
                      {stat.change}
                    </Badge>
                  </div>
                  <div className="text-3xl mb-1">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Charts and Activity */}
          <div className="grid lg:grid-cols-2 gap-8 mb-8">
            {/* Activity Chart */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-xl mb-1">Weekly Activity</h3>
                    <p className="text-sm text-muted-foreground">
                      Skill points earned per day
                    </p>
                  </div>
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={activityData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                    <XAxis dataKey="name" stroke="#6B7280" />
                    <YAxis stroke="#6B7280" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "white",
                        border: "1px solid #E5E7EB",
                        borderRadius: "0.5rem",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="points"
                      stroke="#4A90E2"
                      strokeWidth={3}
                      dot={{ fill: "#4A90E2", r: 5 }}
                      activeDot={{ r: 7 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </Card>
            </motion.div>

            {/* Skill Radar */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
            >
              <Card className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-xl mb-1">Skill Overview</h3>
                    <p className="text-sm text-muted-foreground">
                      Your expertise across categories
                    </p>
                  </div>
                  <Trophy className="w-6 h-6 text-accent" />
                </div>
                <ResponsiveContainer width="100%" height={250}>
                  <RadarChart data={skillData}>
                    <PolarGrid stroke="#E5E7EB" />
                    <PolarAngleAxis dataKey="skill" stroke="#6B7280" />
                    <PolarRadiusAxis angle={90} domain={[0, 100]} stroke="#6B7280" />
                    <Radar
                      name="Skills"
                      dataKey="value"
                      stroke="#6C63FF"
                      fill="#6C63FF"
                      fillOpacity={0.5}
                    />
                    <Tooltip />
                  </RadarChart>
                </ResponsiveContainer>
              </Card>
            </motion.div>
          </div>

          {/* Active Collaborations */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl mb-1">Active Collaborations</h3>
                  <p className="text-sm text-muted-foreground">
                    Track your ongoing skill exchanges
                  </p>
                </div>
                <Button onClick={() => onNavigate('skills')}>
                  Find Collaborators
                </Button>
              </div>

              <div className="space-y-4">
                {activeCollabs.map((collab, idx) => (
                  <motion.div
                    key={collab.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.7 + idx * 0.1 }}
                    whileHover={{ x: 5 }}
                    className="flex items-center gap-4 p-4 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => onNavigate('collaboration')}
                  >
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={collab.avatar} />
                      <AvatarFallback>{collab.partner[0]}</AvatarFallback>
                    </Avatar>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span>{collab.title}</span>
                        <Badge variant="outline" className="text-xs">
                          {collab.skill}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground mb-2">
                        with {collab.partner}
                      </div>
                      <Progress value={collab.progress} className="h-2" />
                    </div>

                    <div className="text-right">
                      <div className="text-2xl">{collab.progress}%</div>
                      <div className="text-xs text-muted-foreground">complete</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </Card>
          </motion.div>

          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8"
          >
            {[
              { icon: Code, label: "Learn Web Dev", color: "bg-blue-500" },
              { icon: Palette, label: "Teach Design", color: "bg-purple-500" },
              { icon: BookOpen, label: "Share Writing", color: "bg-yellow-500" },
              { icon: Users, label: "Join Community", color: "bg-green-500" },
            ].map((action, idx) => (
              <motion.div
                key={idx}
                whileHover={{ scale: 1.05, y: -5 }}
                whileTap={{ scale: 0.95 }}
              >
                <Card className="p-6 text-center cursor-pointer hover:shadow-xl transition-shadow">
                  <div className={`${action.color} w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-3 shadow-lg`}>
                    <action.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-sm">{action.label}</div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </main>
      </div>
    </div>
  );
}

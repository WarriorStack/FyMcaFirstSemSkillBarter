import { motion } from "motion/react";
import { Button } from "./ui/button";
import { Home, Search, ArrowLeft } from "lucide-react";

export function NotFoundPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="text-center max-w-2xl">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", duration: 0.8 }}
          className="mb-8"
        >
          <div className="text-9xl mb-4">404</div>
          <motion.div
            animate={{
              rotate: [0, 10, -10, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="inline-block text-6xl"
          >
            🤔
          </motion.div>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-4xl mb-4"
        >
          Oops! Page Not Found
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-xl text-muted-foreground mb-8"
        >
          Looks like this page went on a skill exchange adventure and didn't come back. 
          Let's get you back on track!
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="flex flex-wrap gap-4 justify-center"
        >
          <Button
            size="lg"
            onClick={() => onNavigate('landing')}
            className="gap-2"
          >
            <Home className="w-5 h-5" />
            Go Home
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => onNavigate('dashboard')}
            className="gap-2"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Dashboard
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => onNavigate('skills')}
            className="gap-2"
          >
            <Search className="w-5 h-5" />
            Explore Skills
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-12 text-sm text-muted-foreground"
        >
          Error Code: 404 | Page Not Found
        </motion.div>
      </div>
    </div>
  );
}

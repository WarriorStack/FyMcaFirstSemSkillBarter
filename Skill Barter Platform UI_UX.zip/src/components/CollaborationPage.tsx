import { useState } from "react";
import { motion } from "motion/react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Textarea } from "./ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import {
  Send,
  Paperclip,
  CheckCircle2,
  Circle,
  Clock,
  MoreVertical,
  Plus,
  Sparkles,
} from "lucide-react";

const messages = [
  {
    id: 1,
    sender: "Sarah Chen",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    text: "Hey! I've started working on the authentication module. Should have it done by tomorrow.",
    time: "10:30 AM",
    isMe: false,
  },
  {
    id: 2,
    sender: "You",
    avatar: "https://images.unsplash.com/photo-1556157382-97eda2d62296?w=100&h=100&fit=crop",
    text: "Awesome! I'm finishing up the UI components. Can you review the design file I shared?",
    time: "10:45 AM",
    isMe: true,
  },
  {
    id: 3,
    sender: "Sarah Chen",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    text: "Just checked it out - looks amazing! Love the color scheme and the animations. 🎨",
    time: "11:02 AM",
    isMe: false,
  },
  {
    id: 4,
    sender: "You",
    avatar: "https://images.unsplash.com/photo-1556157382-97eda2d62296?w=100&h=100&fit=crop",
    text: "Thanks! Let me know if you need any help with the backend integration.",
    time: "11:15 AM",
    isMe: true,
  },
];

const tasks = [
  { id: 1, title: "Set up project repository", status: "done", assignee: "Sarah" },
  { id: 2, title: "Design homepage mockup", status: "done", assignee: "You" },
  { id: 3, title: "Build authentication system", status: "progress", assignee: "Sarah" },
  { id: 4, title: "Create UI components", status: "progress", assignee: "You" },
  { id: 5, title: "Integrate API endpoints", status: "todo", assignee: "Sarah" },
  { id: 6, title: "Add animations & polish", status: "todo", assignee: "You" },
  { id: 7, title: "Testing & deployment", status: "todo", assignee: "Both" },
];

const milestones = [
  { name: "Project Setup", points: 50, completed: true },
  { name: "Design Phase", points: 100, completed: true },
  { name: "Development", points: 200, completed: false, progress: 60 },
  { name: "Testing & Launch", points: 100, completed: false, progress: 0 },
];

export function CollaborationPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [newMessage, setNewMessage] = useState("");

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      // Handle send logic
      setNewMessage("");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" onClick={() => onNavigate('dashboard')} className="mb-6">
            ← Back to Dashboard
          </Button>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-start justify-between mb-6">
              <div>
                <h1 className="text-4xl mb-2">E-commerce Website Project</h1>
                <p className="text-xl text-muted-foreground">
                  Collaboration with Sarah Chen · React Development ⇄ UI/UX Design
                </p>
              </div>
              <Button variant="outline" className="gap-2">
                <MoreVertical className="w-4 h-4" />
                Options
              </Button>
            </div>

            {/* Project Stats */}
            <div className="grid grid-cols-4 gap-4 mb-8">
              {[
                { label: "Progress", value: "65%", color: "text-primary" },
                { label: "Tasks Done", value: "4/7", color: "text-green-500" },
                { label: "Points Earned", value: "150", color: "text-yellow-500" },
                { label: "Days Left", value: "12", color: "text-muted-foreground" },
              ].map((stat, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                >
                  <Card className="p-4 text-center">
                    <div className={`text-3xl ${stat.color} mb-1`}>{stat.value}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content - Tasks & Chat */}
          <div className="lg:col-span-2 space-y-8">
            {/* Tasks Board */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl">Project Tasks</h3>
                  <Button size="sm" className="gap-2">
                    <Plus className="w-4 h-4" />
                    Add Task
                  </Button>
                </div>

                <Tabs defaultValue="all" className="space-y-4">
                  <TabsList>
                    <TabsTrigger value="all">All ({tasks.length})</TabsTrigger>
                    <TabsTrigger value="progress">
                      In Progress ({tasks.filter((t) => t.status === "progress").length})
                    </TabsTrigger>
                    <TabsTrigger value="done">
                      Done ({tasks.filter((t) => t.status === "done").length})
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="all" className="space-y-3">
                    {tasks.map((task, idx) => (
                      <motion.div
                        key={task.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.05 }}
                        whileHover={{ x: 5 }}
                        className={`flex items-center gap-3 p-4 rounded-lg border-2 transition-all cursor-pointer ${
                          task.status === "done"
                            ? "bg-green-50 border-green-200"
                            : task.status === "progress"
                            ? "bg-blue-50 border-blue-200"
                            : "bg-muted/30 border-transparent"
                        }`}
                      >
                        {task.status === "done" ? (
                          <CheckCircle2 className="w-5 h-5 text-green-500" />
                        ) : task.status === "progress" ? (
                          <Clock className="w-5 h-5 text-blue-500 animate-pulse" />
                        ) : (
                          <Circle className="w-5 h-5 text-muted-foreground" />
                        )}
                        <div className="flex-1">
                          <div className={task.status === "done" ? "line-through text-muted-foreground" : ""}>
                            {task.title}
                          </div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {task.assignee}
                        </Badge>
                      </motion.div>
                    ))}
                  </TabsContent>
                </Tabs>
              </Card>
            </motion.div>

            {/* Chat Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card className="p-6">
                <h3 className="text-xl mb-6">Project Chat</h3>

                <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
                  {messages.map((message, idx) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className={`flex gap-3 ${message.isMe ? "flex-row-reverse" : ""}`}
                    >
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={message.avatar} />
                        <AvatarFallback>{message.sender[0]}</AvatarFallback>
                      </Avatar>
                      <div className={`flex-1 max-w-md ${message.isMe ? "text-right" : ""}`}>
                        <div className="flex items-center gap-2 mb-1">
                          {!message.isMe && <span className="text-sm">{message.sender}</span>}
                          <span className="text-xs text-muted-foreground">{message.time}</span>
                        </div>
                        <div
                          className={`inline-block px-4 py-2 rounded-2xl ${
                            message.isMe
                              ? "bg-primary text-white"
                              : "bg-muted"
                          }`}
                        >
                          {message.text}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" size="icon">
                    <Paperclip className="w-4 h-4" />
                  </Button>
                  <Input
                    placeholder="Type your message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  />
                  <Button onClick={handleSendMessage} className="gap-2">
                    <Send className="w-4 h-4" />
                    Send
                  </Button>
                </div>
              </Card>
            </motion.div>
          </div>

          {/* Sidebar - Progress & Info */}
          <div className="space-y-8">
            {/* Collaborator Info */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="p-6">
                <h4 className="mb-4">Collaborator</h4>
                <div className="flex items-center gap-3 mb-4">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop" />
                    <AvatarFallback>SC</AvatarFallback>
                  </Avatar>
                  <div>
                    <div>Sarah Chen</div>
                    <div className="text-sm text-muted-foreground">React Developer</div>
                  </div>
                </div>
                <Button variant="outline" className="w-full" onClick={() => onNavigate('profile')}>
                  View Profile
                </Button>
              </Card>
            </motion.div>

            {/* Overall Progress */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card className="p-6">
                <h4 className="mb-4">Overall Progress</h4>
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Completion</span>
                    <span className="text-2xl">65%</span>
                  </div>
                  <Progress value={65} className="h-3" />
                </div>

                <div className="space-y-4">
                  {milestones.map((milestone, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.4 + idx * 0.1 }}
                      className="space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {milestone.completed ? (
                            <CheckCircle2 className="w-5 h-5 text-green-500" />
                          ) : (
                            <Clock className="w-5 h-5 text-muted-foreground" />
                          )}
                          <span className="text-sm">{milestone.name}</span>
                        </div>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Sparkles className="w-3 h-3 text-yellow-500" />
                          {milestone.points}
                        </div>
                      </div>
                      {!milestone.completed && milestone.progress > 0 && (
                        <Progress value={milestone.progress} className="h-1" />
                      )}
                    </motion.div>
                  ))}
                </div>
              </Card>
            </motion.div>

            {/* Points Exchange Tracker */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card className="p-6 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
                <h4 className="mb-4 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary" />
                  Skill Points Exchange
                </h4>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-muted-foreground">You've earned</span>
                      <span className="text-xl text-primary">+150</span>
                    </div>
                    <Progress value={60} className="h-2" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-muted-foreground">Sarah has earned</span>
                      <span className="text-xl text-accent">+150</span>
                    </div>
                    <Progress value={60} className="h-2" />
                  </div>
                  <div className="pt-4 border-t text-center">
                    <div className="text-sm text-muted-foreground mb-1">Potential Total</div>
                    <div className="text-3xl text-green-500">+450 points</div>
                  </div>
                </div>
              </Card>
            </motion.div>

            {/* Quick Actions */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
            >
              <Card className="p-6">
                <h4 className="mb-4">Quick Actions</h4>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    📁 Share Files
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    📅 Schedule Meeting
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    ⏰ Set Deadline
                  </Button>
                  <Button variant="destructive" className="w-full justify-start">
                    ✋ End Collaboration
                  </Button>
                </div>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

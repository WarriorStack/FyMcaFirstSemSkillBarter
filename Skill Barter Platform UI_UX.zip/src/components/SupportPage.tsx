import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "./ui/accordion";
import { 
  Mail, 
  MessageCircle, 
  Phone, 
  MapPin,
  Search,
  HelpCircle,
  Sparkles,
  CheckCircle,
} from "lucide-react";

const faqs = [
  {
    question: "How does the skill exchange system work?",
    answer: "The skill exchange system allows you to trade your expertise with other students. You offer a skill you're proficient in, and in return, learn a skill you want to develop. Points are earned based on collaboration completion and quality."
  },
  {
    question: "How are skill points calculated?",
    answer: "Skill points are calculated based on several factors: collaboration duration, project complexity, peer ratings, and completion milestones. Typically, a complete collaboration awards 200-500 points to each participant."
  },
  {
    question: "Can I collaborate with multiple people at once?",
    answer: "Yes! You can have multiple active collaborations simultaneously. However, we recommend limiting yourself to 3-5 active projects to ensure quality engagement with each collaborator."
  },
  {
    question: "What happens if a collaboration doesn't work out?",
    answer: "If a collaboration isn't working, you can use our mediation feature or end the collaboration early. Points are distributed fairly based on work completed. We encourage open communication to resolve issues first."
  },
  {
    question: "How do I verify my skills?",
    answer: "Skills can be verified through completed projects, peer reviews, portfolio submissions, or optional skill assessments. Verified skills show a badge on your profile and increase your match quality."
  },
  {
    question: "Is there a cost to use the platform?",
    answer: "Basic access to Skill Barter is completely free! Premium features like advanced analytics, priority matching, and exclusive workshops are available through our Pro membership."
  },
  {
    question: "How does the AI matching system work?",
    answer: "Our AI analyzes your skills, learning goals, collaboration history, availability, and preferences to suggest optimal matches. The system continuously learns from successful collaborations to improve recommendations."
  },
  {
    question: "Can I delete my account and data?",
    answer: "Yes, you have full control over your data. You can delete your account anytime from Settings > Privacy. All your personal data will be permanently removed within 30 days."
  },
];

export function SupportPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);

  const filteredFaqs = faqs.filter(
    faq =>
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" onClick={() => onNavigate('dashboard')} className="mb-6">
            ← Back to Dashboard
          </Button>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl mb-2">Help & Support</h1>
            <p className="text-xl text-muted-foreground">
              We're here to help you with any questions or issues
            </p>
          </motion.div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content - FAQ */}
          <div className="lg:col-span-2 space-y-8">
            {/* Search */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <HelpCircle className="w-6 h-6 text-primary" />
                  <h3 className="text-xl">Frequently Asked Questions</h3>
                </div>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    placeholder="Search for help..."
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </Card>
            </motion.div>

            {/* FAQ Accordion */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="p-6">
                <Accordion type="single" collapsible className="space-y-4">
                  {filteredFaqs.map((faq, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.3 + idx * 0.05 }}
                    >
                      <AccordionItem value={`item-${idx}`} className="border rounded-lg px-4">
                        <AccordionTrigger className="hover:no-underline">
                          <span className="text-left">{faq.question}</span>
                        </AccordionTrigger>
                        <AccordionContent className="text-muted-foreground">
                          {faq.answer}
                        </AccordionContent>
                      </AccordionItem>
                    </motion.div>
                  ))}
                </Accordion>

                {filteredFaqs.length === 0 && (
                  <div className="text-center py-12">
                    <HelpCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">
                      No FAQs found matching "{searchQuery}"
                    </p>
                  </div>
                )}
              </Card>
            </motion.div>

            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card className="p-6">
                <div className="flex items-center gap-2 mb-6">
                  <MessageCircle className="w-6 h-6 text-primary" />
                  <h3 className="text-xl">Still need help? Contact us</h3>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Name</Label>
                      <Input id="name" placeholder="Your name" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" placeholder="you@example.com" required />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject</Label>
                    <Input id="subject" placeholder="What do you need help with?" required />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea
                      id="message"
                      placeholder="Describe your issue or question..."
                      rows={6}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full gap-2">
                    <Send className="w-4 h-4" />
                    Send Message
                  </Button>
                </form>

                <AnimatePresence>
                  {showSuccess && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-3 text-green-700"
                    >
                      <CheckCircle className="w-5 h-5" />
                      <span>Message sent successfully! We'll get back to you soon.</span>
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            </motion.div>
          </div>

          {/* Sidebar - Contact Info */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="p-6">
                <h4 className="mb-6">Contact Information</h4>
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Mail className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground mb-1">Email</div>
                      <div>support@skillbarter.com</div>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Phone className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground mb-1">Phone</div>
                      <div>+1 (555) 123-4567</div>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <MessageCircle className="w-6 h-6 text-secondary" />
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground mb-1">Live Chat</div>
                      <div>Available 24/7</div>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground mb-1">Office</div>
                      <div>123 Innovation St<br />San Francisco, CA 94102</div>
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card className="p-6 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
                <div className="flex items-center gap-2 mb-4">
                  <Sparkles className="w-6 h-6 text-primary" />
                  <h4>Premium Support</h4>
                </div>
                <p className="text-sm text-muted-foreground mb-4">
                  Get priority support, dedicated account manager, and instant responses with our Pro plan.
                </p>
                <Button className="w-full">
                  Upgrade to Pro
                </Button>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card className="p-6">
                <h4 className="mb-4">Quick Links</h4>
                <div className="space-y-2">
                  <Button variant="ghost" className="w-full justify-start">
                    📚 User Guide
                  </Button>
                  <Button variant="ghost" className="w-full justify-start">
                    🎥 Video Tutorials
                  </Button>
                  <Button variant="ghost" className="w-full justify-start">
                    💬 Community Forum
                  </Button>
                  <Button variant="ghost" className="w-full justify-start">
                    📋 Terms of Service
                  </Button>
                  <Button variant="ghost" className="w-full justify-start">
                    🔒 Privacy Policy
                  </Button>
                </div>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Send(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m22 2-7 20-4-9-9-4Z" />
      <path d="M22 2 11 13" />
    </svg>
  );
}

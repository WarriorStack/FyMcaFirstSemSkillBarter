
  # Skill Barter Platform UI/UX

  This is a code bundle for Skill Barter Platform UI/UX. The original project is available at https://www.figma.com/design/3Nqnnkv06BdYUvZnOiqWCe/Skill-Barter-Platform-UI-UX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  